### Project links

Resource                 | Link
-------------------------|---------------------------------------------------
Website                   | https://www.hammerspoon.org/
GitHub page               | https://github.com/Hammerspoon/hammerspoon
Getting Started Guide     | https://www.hammerspoon.org/go/
Spoon Plugin Documentation| https://github.com/Hammerspoon/hammerspoon/blob/master/SPOONS.md
Official Spoon repository | https://www.hammerspoon.org/Spoons
IRC channel               | irc://irc.libera.chat/#hammerspoon
Mailing list              | https://groups.google.com/forum/#!forum/hammerspoon/
LuaSkin API docs          | https://www.hammerspoon.org/docs/LuaSkin/
