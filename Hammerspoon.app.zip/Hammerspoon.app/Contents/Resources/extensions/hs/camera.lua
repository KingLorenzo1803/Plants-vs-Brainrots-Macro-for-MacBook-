--- === hs.camera ===
---
--- Inspect the system's camera devices

local module = require("hs.libcamera")

-- Return Module Object --------------------------------------------------
return module
