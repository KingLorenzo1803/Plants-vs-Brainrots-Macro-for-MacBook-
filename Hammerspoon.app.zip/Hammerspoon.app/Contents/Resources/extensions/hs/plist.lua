--- === hs.plist ===
---
--- Read and write Property List files

local USERDATA_TAG = "hs.plist"
local module       = require("hs.libplist")

-- Return Module Object --------------------------------------------------

return module
